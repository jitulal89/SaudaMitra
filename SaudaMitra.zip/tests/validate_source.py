from pathlib import Path
import re, sys
root = Path(__file__).resolve().parents[1]
js = root / 'app/src/main/assets/www/app.js'
html = root / 'app/src/main/assets/www/index.html'
checks = {
    'app.js exists': js.is_file(),
    'index.html exists': html.is_file(),
    'billing CTA in dashboard': 'Open Billing' in js.read_text(),
    'activation is not shown in navigation': 'data-page="activation"' not in html.read_text(),
    'starter shop created': "name:'Main Shop'" in js.read_text(),
    'Android launcher activity exists': (root/'app/src/main/java/com/saudamitra/app/MainActivity.java').is_file(),
    'GitHub Actions workflow exists': (root/'.github/workflows/build-apk.yml').is_file(),
    'no remote Supabase endpoint in app assets': not re.search(r'https://[^\s"\']+supabase\.(co|in)', js.read_text(), re.I),
}
for label, ok in checks.items(): print(('PASS' if ok else 'FAIL') + ' - ' + label)
sys.exit(0 if all(checks.values()) else 1)
