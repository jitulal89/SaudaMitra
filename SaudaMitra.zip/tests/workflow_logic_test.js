const fs = require('fs');
const vm = require('vm');
const source = fs.readFileSync('app/src/main/assets/www/app.js', 'utf8');
const start = source.indexOf('async function saveBill(){');
const end = source.indexOf('\nfunction ', start + 10);
if (start < 0 || end < 0) throw new Error('saveBill function not found');
const saveBillSource = source.slice(start, end);
const paymentStart=source.indexOf('function planPaymentAllocations(');
const paymentEnd=source.indexOf('\nfunction ',paymentStart+10);
if(paymentStart<0||paymentEnd<0)throw new Error('planPaymentAllocations function not found');
const paymentPlanSource=source.slice(paymentStart,paymentEnd);
let id = 0;
function makeContext(lines, received, paymentStatus='Partial') {
  const products = [
    {id:'p1', name:'MAGAJ KD', unit:'kg', price:500, taxRate:5},
    {id:'p2', name:'PACKING', unit:'piece', price:200, taxRate:18}
  ];
  const shop = {id:'shopA', name:'Santosh Sales Corporation', settings:{billPrefix:'TEST',billStart:1,taxEnabled:true,defaultTax:5}};
  const state = {shops:[shop], activeShopId:'shopA', settings:{billPrefix:'TEST',billStart:1,taxEnabled:true,defaultTax:5}, brokers:[{id:'self',name:'SELF',commissionRate:0,active:true}], sales:[], payments:[], reconciliations:[], ledger:[], audit:[]};
  const values = {
    billShop:'shopA', billDate:'2026-10-12', billCustomer:'c1', billPaymentStatus:paymentStatus,
    billDiscount:'0', billTaxRate:'5', billNotes:'test', billTransportCharge:'0', billPackingCharge:'0',
    billCartingCharge:'0', billOtherCharge:'0', billOtherChargeDescription:'', billTransport:'', billVehicleNo:'',
    billBrokerName:'SELF', billBrokerCommission:'0', billPaidAmount:String(received)
  };
  const billDraft = {shopId:'shopA',date:'2026-10-12',customerId:'c1',paymentStatus,discount:0,lines:lines.map(x=>({...x}))};
  const context = {
    state, billDraft, selectedPayment:'Cash',
    $: id => values[id] === undefined ? null : ({value:values[id]}),
    product: id => products.find(p=>p.id===id), customer: id => id==='c1'?{id:'c1',name:'Test Customer',phone:'9000000000'}:null,
    settingsForShop: id => state.shops.find(s=>s.id===id)?.settings || state.settings,
    balance: () => 1000, shopName: id => state.shops.find(s=>s.id===id)?.name || id,
    logStock: x => state.ledger.push(x), uid: ()=>'id'+(++id), today: ()=>'2026-10-12',
    confirm: () => true, audit: () => {}, save: async()=>{}, newBillDraft:()=>({shopId:'shopA',date:'2026-10-12',lines:[]}),
    navTo:()=>{}, notify:()=>{}, console, Math, Number, String, Error, Date, money:x=>String(Number(x).toFixed(2))
  };
  vm.createContext(context);
  vm.runInContext(saveBillSource, context);
  return context;
}
(async()=>{
  const allocationContext={money:x=>String(Number(x).toFixed(2)),Error};vm.createContext(allocationContext);vm.runInContext(paymentPlanSource,allocationContext);
  const bills=[{id:'b1',billNo:'B1',customerId:'c1',date:'2026-09-01',total:2000,paid:0},{id:'b2',billNo:'B2',customerId:'c1',date:'2026-09-02',total:3000,paid:0},{id:'b3',billNo:'B3',customerId:'c1',date:'2026-09-03',total:5000,paid:0}];
  const fifo=allocationContext.planPaymentAllocations(bills,'c1',4000,'','customer');
  if(fifo.plan.length!==2||fifo.plan[0].bill.id!=='b1'||fifo.plan[0].apply!==2000||fifo.plan[1].bill.id!=='b2'||fifo.plan[1].apply!==2000||fifo.left!==0)throw new Error('FIFO allocation test failed');
  const balances=[bills[0].total-fifo.plan[0].apply,bills[1].total-fifo.plan[1].apply,bills[2].total];
  if(JSON.stringify(balances)!==JSON.stringify([0,1000,5000]))throw new Error('FIFO outstanding balances failed');
  let overspend=false;try{allocationContext.planPaymentAllocations(bills,'c1',11000,'','customer')}catch(e){overspend=true}if(!overspend)throw new Error('Oversized payment should be rejected before mutation');
  const a=makeContext([{productId:'p1',qty:2,rate:500,taxRate:5,sourceShopId:'shopA'}],400);
  await a.saveBill();
  const s=a.state.sales[0];
  if(!s || s.total!==1050 || s.tax!==50 || s.paid!==400 || s.paymentStatus!=='Partial') throw new Error('Partial payment + per-item tax test failed: '+JSON.stringify(s));
  if(a.state.payments.length!==1 || a.state.payments[0].amount!==400 || a.state.ledger.length!==1 || a.state.ledger[0].qty!==-2) throw new Error('Partial payment/stock ledger postings failed');
  const b=makeContext([{productId:'p1',qty:1,rate:100,taxRate:5,sourceShopId:'shopA'},{productId:'p2',qty:1,rate:200,taxRate:18,sourceShopId:'shopA'}],100);
  await b.saveBill();
  const t=b.state.sales[0];
  if(t.subtotal!==300 || t.tax!==41 || t.total!==341 || t.paid!==100 || t.paymentStatus!=='Partial') throw new Error('Mixed item tax test failed: '+JSON.stringify(t));
  console.log('PASS - FIFO allocation ₹4,000 => balances ₹0/₹1,000/₹5,000; overspend rejection; bill save totals, mixed item tax, partial payment, payment record, and stock ledger');
})();
