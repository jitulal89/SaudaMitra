# SaudaMitra v1.0.10 — engineering test candidate

Date: 2026-10-12
Base: v1.0.9 repair-candidate source
Status: **source-level and isolated workflow tests passed; not an Android release**

## Changes in this candidate

1. **Purchase OCR parsing**
   - Matches product names across adjacent OCR lines instead of requiring the whole name and numeric columns on one line.
   - Handles a common OCR failure where the first invoice-quantity column is dropped and the physical weight column remains.
   - Vendor GSTIN extraction is scoped to the detected supplier where possible. The fictional demo's purchaser GSTIN is not incorrectly assigned to the supplier.
   - Rejects common false invoice-number matches such as `M/s` and `DATE`.
   - Shows an explicit OCR error when the Android bridge returns `OCR_ERROR:` instead of treating the error as extracted text.

2. **Edit sales invoice**
   - Replaced per-line stock-shop dropdowns with a single bill-level shop selector.
   - Editing re-posts revised item stock movements to the selected bill-level shop.
   - Added per-item tax selection to the edit form and computes tax from each item's selected rate.
   - Changing a product in the edit form defaults its tax to the product setup rate (or shop default).

3. **WhatsApp bill message**
   - The WhatsApp action now includes line items, quantities, rates, line amounts, subtotal, discount, tax, charges, total, paid and balance.
   - This action sends **formatted bill text**, not a PDF attachment. PDF-to-WhatsApp attachment sharing remains unverified/not implemented in this candidate.

4. **Mobile purchase editor**
   - Added narrow-screen CSS for purchase item rows to reduce horizontal overflow in the modal.

5. **Version metadata**
   - Updated to versionName `1.0.10`, versionCode `8`.

## Tests run

- `node --check app/src/main/assets/www/app.js` — PASS.
- `python tests/validate_source.py` — PASS.
- `python app/src/main/assets/www/tests/validate_package.py` — PASS.
- `python app/src/main/assets/www/tests/validate_purchase.py` — PASS.
- `node tests/workflow_logic_test.js` — PASS: bill save, mixed item tax (5% and 18%), partial payment, payment record and stock ledger posting.
- Rendered the fictional vendor invoice PDF to a 250 DPI image and ran local Tesseract OCR. The OCR text was not cleanly laid out and dropped the narrow invoice quantity column. The revised parser extracted `MAGAJ KD`, 20 kg and ₹500/kg from the OCR text, and extracted vendor name, invoice number and date. It left the invalid fictional vendor GSTIN blank rather than misassigning the purchaser's GSTIN.
- Also ran OCR on the supplied source invoice image. The metadata parser identified the seller's GSTIN rather than the buyer's GSTIN. The invoice-number field was correctly left blank when OCR supplied no reliable invoice number.

## Not verified — do not interpret as release sign-off

- Android Gradle build: **not run**. This environment has no configured Android SDK/`ANDROID_HOME` and no Gradle executable.
- Browser UI automation: blocked by environment policy for both local HTTP and `file://` navigation (`ERR_BLOCKED_BY_ADMINISTRATOR`).
- ML Kit OCR inside the actual Android APK: not run on a device. The parser was tested against OCR text extracted from rendered PDF images; that does not prove the Android bridge itself works on the phone.
- Broker Management and Payments navigation/search interactions: source routes and handlers are present; full UI interaction is not device-verified.
- FIFO allocation example (₹2,000 + ₹3,000 + ₹5,000, receive ₹4,000): implementation is present but not browser/device end-to-end verified.
- Print dialog, A4/80mm/58mm physical page output, WhatsApp PDF attachment, Android share sheet, and Posiflow thermal printer: not device-verified. WhatsApp currently sends formatted text only.
- Full app persistence/reopen/backup-restore flow: not device-verified.

## Release recommendation

Use this ZIP for source review and continued testing only. Do not use it for live accounting or GST compliance until a real APK is built and the remaining Android/device acceptance tests pass.
