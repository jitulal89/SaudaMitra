# SaudaMitra Android Test Build v1.0.1

Offline-first multi-shop billing and inventory test build. This project is independent of DukaanBill and does not use Supabase or a cloud backend.

## What's changed in v1.0.1

- Billing is available from the home page and the top Billing button without owner/device activation.
- Owner/shop-device activation is deferred for the owner mobile setup phase; the activation screen is hidden from the main navigation in this test build.
- On a fresh installation, a local `Main Shop` is created so the user can open Billing immediately. Rename it under **Shops & Team**.
- Android WebView wrapper and GitHub Actions workflow included.
- Data remains local to this Android installation. Multi-device synchronization is not included.

## Build APK through GitHub Actions

1. Create a new **private** GitHub repository for SaudaMitra.
2. Extract this ZIP on your computer and upload the **contents** of the extracted folder to the repository root. The `.github/workflows/build-apk.yml` file must be included.
3. Commit/push to `main` (or `master`), or open **Actions → Build SaudaMitra APK → Run workflow**.
4. Wait for the workflow to finish successfully.
5. Open the completed workflow run, scroll to **Artifacts**, and download `SaudaMitra-debug-apk`.
6. Extract the artifact ZIP; install `app-debug.apk` on your Android phone. You may need to allow installation from your browser/file manager.

The workflow uses JDK 17, Gradle 8.9, Android SDK 35 and runs `gradle clean assembleDebug` similar to the DukaanBill build workflow.

## App usage

- Open the app; it starts at Dashboard with **Open Billing** available.
- A starter shop called `Main Shop` is created on first run. Edit its details in **Shops & Team**.
- Add products before creating sales bills. Record purchases/stock first or choose a source shop that has sufficient stock.
- For cross-shop fulfilment, choose the selling shop and each line's stock source shop. The source stock is deducted once and a pending reconciliation record is created.
- Use **Settings & Backup** to export a JSON backup regularly.

## Offline storage and limitations

- No internet permission or remote backend is used by the Android app.
- The app uses the bundled local web assets and local browser storage. Clearing app data or uninstalling the app may erase business data; export backups regularly.
- This is a debug APK workflow, not a signed production release. Release signing is not configured.
- Printer behavior, backup downloads/restores, and full billing flows must be verified on the target phone before production use.
- Owner activation is intentionally bypassed only for this test build. Do not use this as a production activation/security model.
- Multi-device sync, complete GST compliance, advanced staff permissions, purchase returns and batch/expiry management are not part of this release.
