# SaudaMitra Android Test Build v1.0.5

Offline-first multi-shop billing and inventory test build. This project is independent of DukaanBill and does not use Supabase or a cloud backend.

## What's changed in v1.0.1

- Billing is available from the home page and the top Billing button without owner/device activation.
- Owner/shop-device activation is deferred for the owner mobile setup phase; the activation screen is hidden from the main navigation in this test build.
- On a fresh installation, a local `Main Shop` is created so the user can open Billing immediately. Rename it under **Shops & Team**.
- Android WebView wrapper and GitHub Actions workflow included.
- Data remains local to this Android installation. Multi-device synchronization is not included.

## Build APK through GitHub Actions

1. Create a new **private** GitHub repository for SaudaMitra.
2. Extract this ZIP on your computer and upload the **contents** of the extracted folder to the repository root. The `.github/workflows/build-apk.yml` file must be included.
3. Commit/push to `main` (or `master`), or open **Actions → Build SaudaMitra APK → Run workflow**.
4. Wait for the workflow to finish successfully.
5. Open the completed workflow run, scroll to **Artifacts**, and download `SaudaMitra-debug-apk`.
6. Extract the artifact ZIP; install `app-debug.apk` on your Android phone. You may need to allow installation from your browser/file manager.

The workflow uses JDK 17, Gradle 8.9, Android SDK 35 and runs `gradle clean assembleDebug` similar to the DukaanBill build workflow.

## App usage

- Open the app; it starts at Dashboard with **Open Billing** available.
- A starter shop called `Main Shop` is created on first run. Edit its details in **Shops & Team**.
- Add products before creating sales bills. Record purchases/stock first or choose a source shop that has sufficient stock.
- For cross-shop fulfilment, choose the selling shop and each line's stock source shop. The source stock is deducted once and a pending reconciliation record is created.
- Use **Settings & Backup** to export a JSON backup regularly.

## Offline storage and limitations

- No internet permission or remote backend is used by the Android app.
- The app uses the bundled local web assets and local browser storage. Clearing app data or uninstalling the app may erase business data; export backups regularly.
- This is a debug APK workflow, not a signed production release. Release signing is not configured.
- Printer behavior, backup downloads/restores, and full billing flows must be verified on the target phone before production use.
- Owner activation is intentionally bypassed only for this test build. Do not use this as a production activation/security model.
- Multi-device sync, complete GST compliance, advanced staff permissions, purchase returns and batch/expiry management are not part of this release.


## v1.0.4 repair candidate (superseded) (2026-10-11)

Changes in this candidate:
- Backup export awaits persistence and uses the Android bridge to save JSON into Downloads/SaudaMitra.
- Restore accepts versioned SaudaMitra JSON and merges missing schema defaults while preserving activation secrets on the device.
- Invoice display uses the selected shop's profile/settings.
- Billing customer search is available by name, phone and GSTIN.
- Sales editor allows audited changes to customer/date/discount/charges/transport/vehicle/broker/notes; item quantities and rates are deliberately locked to protect stock history.
- Billing includes transport, packing, carting, additional charge description, vehicle number, transporter and broker commission fields.
- Demo data loader provides Santosh Sales Corporation, Naira Industries, a demo customer/supplier, broker, product catalogue, opening stock, purchase and sample invoice. Demo tax/HSN values must be verified before real use.
- Android WebView file chooser and JSON download bridge added for logo and supplier invoice uploads/backup.

## Validation status
- JavaScript syntax check: PASS.
- Repository source/package validation scripts: PASS.
- ZIP integrity: checked during packaging.
- Android APK build and device-level end-to-end tests: NOT RUN in this environment (Gradle is not installed; browser launch is blocked by the environment). Run the supplied GitHub Actions workflow and then perform device testing before using real invoices.

This is not yet a complete statutory accounting/tax product. Tax invoice line-level GST/HSN treatment, double-entry posting, OCR extraction of vendor bill line items, and full edit/reversal workflows still require implementation and testing.


## v1.0.5 purchase / vendor repair candidate

- Clean installation and an empty one-shop `Main Shop` installation seed demo records for Santosh Sales Corporation and Naira Industries. Existing non-empty business records are not overwritten.
- The demo purchase records are based on the two supplied invoices: Santosh Sales Corporation GST/1575 dated 31/08/2026 and Naira Industries GST/190 dated 25/04/2026. The source invoice fields are reproduced as demo data; verify all GSTIN/FSSAI/HSN/tax details before live use.
- Purchase attachment OCR uses bundled Android ML Kit text recognition for images and PDF pages. It suggests invoice date, vendor name, GSTIN, invoice number and matching item quantities/rates when text is recognizable. Always verify extracted data; OCR does not guarantee exact accounting values.
- Vendor is automatically created when a purchase is saved with a new vendor name. Vendor management is available in the **Vendors** menu.
- Existing purchase bills can be edited, including item rows and quantities/rates. Saving edits reverses old stock movements and posts the revised movements. Tax and hamali/other charges can be edited.
- Sales and purchase lists default to the active shop; choose **All shops** to see all shops. Customer and vendor masters have a shop filter.

### v1.0.5 verification status

JavaScript syntax, package/source validation, and OCR item-row parser tests passed. An Android Gradle build and device end-to-end tests were not run in this environment because Gradle/Android build execution is unavailable here. Do not use this candidate for live billing until GitHub Actions builds the APK and the OCR, edit/stock reversal, demo seed and shop-filter workflows have been verified on the phone.
