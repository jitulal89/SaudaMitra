# SaudaMitra v1.0.8 — repair candidate test report

## Fixes applied to source
- Fixed a temporal-dead-zone bug in `saveBill()`: broker commission was calculated using `subtotal` before `subtotal` was declared. This matches the exact Android toast in the supplied screenshot.
- Sales bill lines now show an individual tax-rate selector (0%, 5%, 12%, 18%, 28%), initialized from product setup tax rate or the shop default. Billing total and saved tax are calculated from each line’s tax rate.
- PDF OCR rendering increased from 2x display rendering to higher-resolution print rendering (3x–5x, bounded by page dimensions) for better text recognition on invoice PDFs.
- OCR exceptions are returned to the UI as a visible diagnostic message rather than an empty OCR result.
- Product OCR matching normalizes punctuation and whitespace before matching catalog names.
- SELF broker is deduplicated during app startup and demo data seeding.
- Mobile purchase/edit modal and bill-line layout receive responsive overflow fixes.
- Android version bumped to 1.0.8 / versionCode 6.

## Automated checks run
- `node --check app/src/main/assets/www/app.js`: PASS
- `tests/validate_source.py`: PASS
- `app/src/main/assets/www/tests/validate_package.py`: PASS
- `app/src/main/assets/www/tests/validate_purchase.py`: PASS for the included representative Santosh/Naira OCR line samples
- ZIP integrity check: PASS after packaging

## Not yet verified
- Android Gradle build was not run in this environment.
- OCR has not been executed against the attached PDF inside a built APK or on the user’s physical phone. Higher resolution is a targeted correction, not proof of successful extraction.
- The user’s reported Broker Management/payment page navigation, partial payment input, printing/WhatsApp/thermal share, edit modal, and full search workflows still require device/browser end-to-end tests. They are not claimed as fully verified by these source checks.
- Individual line tax controls and tax totals pass syntax/source validation only; they require browser/Android interaction tests before production use.

## Required acceptance tests
1. Build/install APK; create a ₹500 sales line with 5% tax and a second line with 18%; confirm line-level tax and total.
2. Save bill with broker commission calculation; ensure `SELF` has zero commission and appears once.
3. Open Purchases, upload `SaudaMitra_Demo_Purchase_Bill_Fictional_Vendor_OCR_Test.pdf`, run OCR, and confirm visible error details or extracted values; validate all fields manually.
4. Open Broker Management and Customer & Vendor Payments; record ₹4,000 against the demo ₹2,000/₹3,000/₹5,000 invoices and verify FIFO balances.
5. Test edit sale/purchase, stock reversal, shop-specific inventory, print preview, paper sizes, PDF save, WhatsApp share and thermal share on Android.
