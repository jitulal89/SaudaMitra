# SaudaMitra v1.0.6 Repair Candidate — Validation Report

## Changes made
- Fixed a definite Billing/New Bill rendering crash: the billing summary referenced an undefined `charges` variable. Charges are now calculated before rendering, included in displayed totals, and included in tax calculation.
- Expanded Edit invoice to allow adding/removing item lines and editing product, quantity, rate, and stock-source shop as well as customer/date/discount/tax/transport/packing/carting/other charges/vehicle/broker details.
- Editing a saved invoice appends stock-ledger reversal events for original item lines and new events for revised lines, and rebuilds pending cross-shop reconciliation rows for that invoice.
- Added basic validation for item rows and amounts.

## Checks run
- `node --check app/src/main/assets/www/app.js`: PASS
- `python tests/validate_source.py`: PASS
- `python app/src/main/assets/www/tests/validate_package.py`: PASS
- ZIP integrity: PASS

## Not verified
- Android Gradle/APK build could not be run because Gradle is not installed in this environment.
- No Android device is available here to verify button taps, database migrations, real stock reconciliation, or OCR against the uploaded PDF. This is a repair candidate, not a device-verified release.
- OCR and purchase form flow remain to be validated in the rebuilt APK. Do not use for production invoices until device tests and arithmetic checks are completed.
