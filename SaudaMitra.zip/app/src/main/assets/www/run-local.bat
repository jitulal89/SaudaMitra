@echo off
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (
  start "SaudaMitra local server" /min py -m http.server 8765
) else (
  where python >nul 2>nul
  if %errorlevel%==0 (
    start "SaudaMitra local server" /min python -m http.server 8765
  ) else (
    echo Python 3 is required to run the offline local server.
    pause
    exit /b 1
  )
)
timeout /t 2 >nul
start "" http://127.0.0.1:8765/index.html
echo SaudaMitra is running locally. Keep this folder and its database profile safe.
echo Close the minimized server window to stop the local server.
