# SaudaMitra v1.0.1 — Offline working model

**Har Sauda, Har Dukaan, Ek Saath.**

SaudaMitra is a separate, offline-first multi-shop billing and inventory working model. It does not use Supabase, a cloud database, an authentication server, or a sync service. Business data is stored in the local browser database (IndexedDB, with a localStorage fallback).

## Included in this version

- Owner/device activation concept using a release-specific RSA signing key; no activation server.
- Business profile and multiple shop setup.
- Shared product, customer, and supplier masters.
- Opening stock, supplier purchases, stock adjustments and stock ledger.
- Sales invoices with line items, discounts, optional simple tax, payment status and payment method.
- Stock-source selection per invoice line; a sale at Shop B can deduct stock from Shop A.
- Cross-shop mismatch report and linked internal fulfilment document that does **not** post a second stock movement.
- Shop-wise and consolidated inventory views.
- Sales, purchase, stock, customer/supplier outstanding and reconciliation reports.
- CSV exports, JSON backup/restore, audit history, print/PDF through the system print dialog.
- Responsive UI, offline service-worker shell cache and installable PWA manifest.

## Important platform note

This package is a cross-platform **PWA working model**, not signed native installers. It can run in modern browsers on Android, Windows, macOS and iOS/iPadOS. On Windows/macOS/Android, install it from a browser that supports app installation. On Apple mobile devices, use Safari's **Add to Home Screen** after the app has been delivered over HTTPS. The initial app shell must be loaded/installed once; after caching, routine operations are offline.

No `.apk`, `.ipa`, `.msix`, `.exe` or `.dmg` is included. Native builds require platform build toolchains and signing; in particular, iOS/macOS builds require Apple tooling. Flutter officially supports native Windows/macOS/iOS/Android targets, but this working model is deliberately delivered as a no-backend PWA so it can be exercised without a cloud service.

## Run on Windows

1. Extract the ZIP to a permanent folder.
2. Ensure Python 3 is installed.
3. Double-click `run-local.bat`.
4. It opens `http://127.0.0.1:8765/index.html` in your browser.
5. Keep the folder and browser profile. Browser data is local to that browser profile.

## Run on macOS/Linux

1. Extract the ZIP to a permanent folder.
2. Run `./run-local.sh` from Terminal.
3. Open `http://127.0.0.1:8765/index.html` in a browser.

For PWA install/offline caching, browsers require a secure context (HTTPS or localhost). Do not open this through an ordinary non-secure LAN IP and expect service-worker installation.

## Owner activation (deferred for this test build)

1. Owner and shop-device activation are intentionally bypassed in this Android test build. The activation code remains reserved for the owner-device phase.
2. Open the separately supplied `SaudaMitra_Owner_Private_Key.txt` in a text editor.
3. Paste the complete PEM contents into the Owner Private Key field.
4. Create and confirm an Owner PIN (minimum 6 characters).
5. The app verifies that the key matches this release's embedded public key, encrypts the key locally with AES-GCM using a PBKDF2-derived key, and activates this installation as the owner device.
6. Then create your business and shops.

Keep the owner private key file offline and private. Do not put it in a public repository or send it to shop staff. This key is specific to this SaudaMitra release. If it is lost, owner approvals for new installations cannot be created with this key.

### Shop-device activation

On a new installation, select **Generate shop activation request**, transfer the request JSON to the owner device, paste it into **Approve another device**, enter the owner PIN, and send the signed token back. Paste the token into the requesting device and verify it. No cloud service is used. This authorizes the local installation only; it does **not** copy business data to it. Multi-device data synchronization is intentionally not implemented yet.

## Cross-shop fulfilment behavior

Example: Shop A has 100 kg of Kaju. Shop B bills a customer for 50 kg. In the bill, set Shop B as the selling shop and Shop A as the stock source. The system:

- Creates the customer invoice under Shop B.
- Deducts 50 kg once from Shop A's ledger.
- Creates a pending cross-shop reconciliation linked to the invoice.
- Allows an internal fulfilment document to be generated.
- Does not deduct stock again when the document is generated.

The internal document is a reconciliation aid, not automatically a GST tax invoice. Confirm the correct accounting and GST treatment for the actual legal entities and registrations.

## Backup and data safety

- Download JSON backups regularly and store them separately from the device.
- Backup files do not include the owner private key, encrypted key copy, or PIN verifier.
- Restore replaces business records but retains the activation state of the current installation.
- Clearing browser data or uninstalling the PWA can erase local business records.
- Multi-device sync is not present. Different devices have independent databases.

## Current v1 limitations (important)

This is a usable working model for the core workflows, not a certified accounting/GST product. It does not yet include: native Android/Windows/macOS/iOS installers; multi-device sync; full employee permission management; partial-line returns; complete customer/supplier payment allocation workflows; purchase returns; batch/expiry tracking; e-invoice/e-way bill; GST return filing; multi-rate CGST/SGST/IGST invoice calculations; or legally reviewed invoice numbering. Simple tax calculation is optional and should not be treated as statutory GST compliance. Printing is through the browser/system print dialog and needs testing with each target printer.

## Tests

- `node --check app.js` — JavaScript syntax validation.
- Owner RSA key pair was checked against the embedded public key.
- `tests/validate_package.py` checks required assets, PWA metadata, core UI modules, and that the owner private key is not included in the application source ZIP.
- `tests/smoke_test.py` is an end-to-end browser script, but it could not be run in the authoring environment because Chromium navigation was blocked by the environment's administrator policy. Run it in a normal local development environment after adjusting the base URL and owner-key path.

See `TEST_REPORT.md` for the validation boundary and manual acceptance checklist.
