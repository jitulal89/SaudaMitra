# SaudaMitra v1.0.0 — Validation report

## Completed checks

- Added settings UI fields for business identity, logo, bank details, invoice headers/footers, document type/copy label, print visibility, paper size and additional-charge tax defaults.
- Added configurable invoice print header/footer rendering and amount-in-words helper for saved sales invoices.
- Added mobile safe-area padding refinements.

- JavaScript parser check (`node --check app.js`): passed.
- PWA manifest JSON parse and required file presence: passed.
- Source bundle checked to ensure the owner private key is not embedded: passed.
- RSA owner key pair checked against the embedded release public key using WebCrypto-compatible RSA-SHA256: passed.
- Cross-shop workflow inspected: invoice line stores selling shop and stock source; sale posting records the stock decrease at the selected source shop; reconciliation records the mismatch; internal-document generation adds a document record without posting another stock movement.
- Local-only architecture checked: no Supabase or remote database client included.

## Browser end-to-end test status

An automated Playwright smoke test is included under `tests/smoke_test.py` for a normal development environment. It exercises owner activation, shop setup, Kaju opening stock, cross-shop sale, reconciliation document generation and backup download. In the authoring environment, Chromium navigation to both localhost and local files was blocked by an administrator policy (`ERR_BLOCKED_BY_ADMINISTRATOR`), so the full browser test could not be completed here. This is an environment limitation, not a passing E2E result.

## Manual acceptance test to run after download

1. Start the app using `run-local.bat` or `run-local.sh`.
2. Configure the owner using the separately supplied private key and an Owner PIN.
3. Create Shop A and Shop B.
4. Add product Kaju with opening stock 100 kg in Shop A.
5. Switch to Shop B and create a customer bill for 50 kg Kaju, choosing Shop A as the stock source.
6. Confirm Shop A has 50 kg remaining, Shop B has 0 kg, and a pending reconciliation appears.
7. Generate the internal document. Confirm stock remains 50 kg total and does not deduct twice.
8. Mark the reconciliation complete only after reviewing the document.
9. Download a backup, restore it in a test browser profile, and confirm records remain present.
10. Test printing and PDF save on each target platform and printer model before production use.

## Known release boundary

This is a PWA working model, not a signed native app release or a certified accounting/GST package. See README.md for features not yet implemented and platform build requirements.
