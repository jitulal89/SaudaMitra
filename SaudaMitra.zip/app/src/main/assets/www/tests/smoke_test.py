"""Optional browser smoke test for the local SaudaMitra web assets.
Run a local server at http://127.0.0.1:8765 first, then run this script with Playwright installed.
"""
import os
from playwright.sync_api import sync_playwright
BASE_URL=os.environ.get('SAUDAMITRA_BASE_URL','http://127.0.0.1:8765/index.html')
errors=[]
with sync_playwright() as p:
    browser=p.chromium.launch(headless=True)
    page=browser.new_page(viewport={"width":1440,"height":1000})
    page.on('pageerror',lambda e: errors.append(str(e)))
    page.on('console',lambda m: errors.append('console: '+m.text) if m.type=='error' else None)
    page.goto(BASE_URL,wait_until='domcontentloaded')
    page.wait_for_timeout(1800)
    shops=page.locator('#activeShop').inner_text()
    assert 'Santosh Sales Corporation' in shops and 'Naira Industries' in shops, shops
    page.locator('.nav-item[data-page="purchases"]').click(); page.wait_for_timeout(300)
    page.locator('#purchaseShopFilter').select_option(label='All shops'); page.wait_for_timeout(300)
    purchase_text=page.locator('#purchasesTable').inner_text()
    assert 'GST/190' in purchase_text and 'GST/1575' in purchase_text, purchase_text
    assert page.get_by_role('button',name='Edit bill').count() >= 2
    page.locator('.nav-item[data-page="suppliers"]').click(); page.wait_for_timeout(300)
    assert 'Naira Industries' in page.locator('#suppliersTable').inner_text()
    assert 'Santosh Sales Corporation' in page.locator('#suppliersTable').inner_text()
    page.locator('.nav-item[data-page="sales"]').click(); page.wait_for_timeout(300)
    assert page.locator('#salesShopFilter').input_value() == page.locator('#activeShop').input_value()
    browser.close()
    if errors: raise SystemExit('Browser errors: '+repr(errors))
print('PASS: demo seed, shop-wide purchase filter, purchase edit actions, vendor management, and active-shop sales filter')
