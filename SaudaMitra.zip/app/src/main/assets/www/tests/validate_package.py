from pathlib import Path
import json, re, subprocess, sys
ROOT=Path(__file__).resolve().parents[1]
required=['index.html','styles.css','app.js','sw.js','manifest.webmanifest','README.md','assets/icon.svg','assets/icon-192.png','assets/icon-512.png','assets/apple-touch-icon.png']
missing=[p for p in required if not (ROOT/p).is_file()]
assert not missing, f'Missing files: {missing}'
html=(ROOT/'index.html').read_text()
js=(ROOT/'app.js').read_text()
manifest=json.loads((ROOT/'manifest.webmanifest').read_text())
assert manifest['name']=='SaudaMitra' and manifest['display']=='standalone'
assert 'indexedDB' in js and 'localStorage' in js
assert 'Cross-shop Reconciliation' in html and 'inventory' in js
assert 'function saveBill()' in js and 'function internalDoc(' in js
assert 'type:\'SALE\'' in js and 'does not post stock movements' in js
assert 'supabase' not in js.lower(), 'Cloud/Supabase code should not be included'
assert '-----BEGIN PRIVATE KEY-----' not in js, 'Private key must not be embedded in app source'
assert not (ROOT/'SaudaMitra_Owner_Private_Key.txt').exists(), 'Owner private key must be separate from source ZIP'
assert all((ROOT/p).stat().st_size>0 for p in required)
subprocess.run(['node','--check',str(ROOT/'app.js')],check=True)
print('PASS: required assets, PWA manifest, local-only storage, cross-shop workflow, private-key separation, and JavaScript syntax.')
