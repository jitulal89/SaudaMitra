from pathlib import Path
import subprocess
ROOT=Path(__file__).resolve().parents[1]
js=(ROOT/'app.js').read_text()
checks={
 'purchase edit action':'editPurchase:' in js and 'function openPurchaseForm(purchaseId=null)' in js,
 'automatic vendor creation':'Created automatically from purchase invoice' in js,
 'OCR bridge':'recognizeInvoice(invoiceAttachment.dataUrl' in js,
 'OCR item extraction':'function parsePurchaseLinesFromOcr(text)' in js,
 'demo invoice GST/190':"purchaseNo:'GST/190'" in js,
 'demo invoice GST/1575':"purchaseNo:'GST/1575'" in js,
 'shop-wise purchase filter':'purchaseShopFilter' in js,
 'shop-wise vendor/customer filter':'masterShopFilter' in js,
 'fresh-install demo seed':'await loadDemoData();return;' in js,
}
for name,ok in checks.items():
 print(('PASS' if ok else 'FAIL')+' - '+name)
if not all(checks.values()): raise SystemExit(1)
# Exercise the OCR row parser against the two uploaded invoice row formats.
source=js.split('function parsePurchaseLinesFromOcr(text){',1)[1].split('\nfunction ',1)[0]
fn='function parsePurchaseLinesFromOcr(text){'+source
script=f"const state={{products:[{{id:'w400',name:'KAJU W400',hsn:'080132'}},{{id:'w240',name:'KAJU W240',hsn:'080132'}},{{id:'magaj',name:'MAGAJ KD',hsn:'120770'}}]}}; {fn}; const a=parsePurchaseLinesFromOcr('1 KAJU W400 080132 5 50.000 7428.57 10.00 5% 37142.85\\n2 KAJU W240 080132 4 40.000 8380.95 10.00 5% 33523.81'); const b=parsePurchaseLinesFromOcr('1 MAGAJ KD 120770 1 20.000 5000.00 10.0 5% 10000.00'); if(a.length!==2||a[0].qty!==50||Math.abs(a[0].cost-742.857)>0.01||a[1].qty!==40||Math.abs(a[1].cost-838.095)>0.01||b.length!==1||b[0].qty!==20||b[0].cost!==500) process.exit(1); console.log('PASS - OCR parser sample rows (Naira W400/W240 and Santosh MAGAJ KD)');"
subprocess.run(['node','-e',script],check=True)
