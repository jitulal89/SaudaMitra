from pathlib import Path
import subprocess
ROOT=Path(__file__).resolve().parents[1]
js=(ROOT/'app.js').read_text()
checks={
 'purchase edit action':'editPurchase:' in js and 'function openPurchaseForm(purchaseId=null)' in js,
 'automatic vendor creation':'Created automatically from purchase invoice' in js,
 'OCR bridge':'recognizeInvoice(invoiceAttachment.dataUrl' in js,
 'OCR item extraction':'function parsePurchaseLinesFromOcr(text)' in js,
 'demo invoice GST/190':"purchaseNo:'GST/190'" in js,
 'demo invoice GST/1575':"purchaseNo:'GST/1575'" in js,
 'shop-wise purchase filter':'purchaseShopFilter' in js,
 'shop-wise vendor/customer filter':'masterShopFilter' in js,
 'fresh-install demo seed':'await loadDemoData();return;' in js,
 'bill-level shop assignment in edit':"field('shopId','Bill / stock shop'" in js and 'shopId:newShopId' in js,
 'per-item tax in edit':"data-sale-field=\"taxRate\"" in js and 'Number(l.taxRate??product(l.productId)?.taxRate??cfg.defaultTax??0)' in js,
 'detailed WhatsApp invoice text':'ITEMS' in js and 'itemLines' in js and 'Balance: ${money(Math.max(0,s.total-(s.paid||0)))}' in js,
 'FIFO payment allocation helper':"function planPaymentAllocations(records,partyId,amount,selectedBillId='',partyType='customer')" in js and 'planPaymentAllocations(records,party.id,amount,selected,kind)' in js,
}
for name,ok in checks.items():
 print(('PASS' if ok else 'FAIL')+' - '+name)
if not all(checks.values()): raise SystemExit(1)
# Exercise the OCR row parser against the two uploaded invoice row formats.
source=js.split('function parsePurchaseLinesFromOcr(text){',1)[1].split('\nfunction ',1)[0]
fn='function parsePurchaseLinesFromOcr(text){'+source
script=f"const state={{products:[{{id:'w400',name:'KAJU W400',hsn:'080132'}},{{id:'w240',name:'KAJU W240',hsn:'080132'}},{{id:'magaj',name:'MAGAJ KD',hsn:'120770',unit:'kg'}}]}}; {fn}; const a=parsePurchaseLinesFromOcr('1 KAJU W400 080132 5 50.000 7428.57 10.00 5% 37142.85\\n2 KAJU W240 080132 4 40.000 8380.95 10.00 5% 33523.81'); const b=parsePurchaseLinesFromOcr('1 MAGAJ KD 120770 1 20.000 5000.00 10.0 5% 10000.00'); const c=parsePurchaseLinesFromOcr('MAGAJ\\nKD 120770\\n20.000 5000.00 5% 10000.00'); if(a.length!==2||a[0].qty!==50||Math.abs(a[0].cost-742.857)>0.01||a[1].qty!==40||Math.abs(a[1].cost-838.095)>0.01||b.length!==1||b[0].qty!==20||b[0].cost!==500||c.length!==1||c[0].qty!==20||c[0].cost!==500) process.exit(1); console.log('PASS - OCR parser clean invoice rows and split-line OCR (including quantity-column loss)');"
subprocess.run(['node','-e',script],check=True)

# Run isolated business-logic workflow checks for partial payment and mixed item tax.
subprocess.run(['node', str(ROOT.parents[4]/'tests'/'workflow_logic_test.js')], check=True)
# Run the real rendered-PDF OCR text fixture through vendor/date/invoice parsing.
ocr_fixture=(ROOT.parents[4]/'tests'/'fixtures'/'fictional_vendor_invoice_tesseract_ocr.txt').read_text()
meta_source=js.split('function parsePurchaseOcr(text){',1)[1].split('\nfunction ',1)[0]
meta_fn='function parsePurchaseOcr(text){'+meta_source
meta_script=f"{meta_fn}; const p=parsePurchaseOcr({ocr_fixture!r}); if(p.vendorName!=='DEMO SPICE & GROCERY SUPPLIERS'||p.invoiceNo!=='DEMO-PUR-26001'||p.date!=='2026-09-15'||p.gstin!=='') process.exit(1); console.log('PASS - rendered-PDF OCR metadata: vendor/invoice/date correct and buyer GSTIN not misassigned');"
subprocess.run(['node','-e',meta_script],check=True)
line_script=f"const state={{products:[{{id:'magaj',name:'MAGAJ KD',hsn:'120770',unit:'kg'}}]}}; {fn}; const rows=parsePurchaseLinesFromOcr({ocr_fixture!r}); if(rows.length!==1||rows[0].productId!=='magaj'||rows[0].qty!==20||rows[0].cost!==500) process.exit(1); console.log('PASS - full rendered-PDF OCR text extracts MAGAJ KD at 20 kg / ₹500 per kg');"
subprocess.run(['node','-e',line_script],check=True)
