# SaudaMitra v1.0.5 Purchase/Vendor Repair Validation Report

| Check | Result |
|---|---|
| `node --check app/src/main/assets/www/app.js` | PASS |
| `python tests/validate_source.py` | PASS |
| `python app/src/main/assets/www/tests/validate_package.py` | PASS |
| Purchase feature source checks | PASS |
| OCR parser test using Naira invoice rows (W400/W240) | PASS |
| OCR parser test using Santosh invoice row (MAGAJ KD) | PASS |
| ZIP integrity | PASS after packaging |
| Android Gradle/APK build | NOT RUN in this environment; Gradle unavailable |
| Android device OCR/purchase-edit end-to-end | NOT RUN; requires built APK on Android device |
| Playwright browser smoke test | NOT RUN in this environment |

The OCR parser tests use representative text rows from the supplied invoices, not a live OCR run against the physical files. The OCR-enabled Android code is included, but its actual OCR quality, APK compilation and device behavior still require GitHub Actions build and phone testing. Treat all seeded invoice data as DEMO until source details and arithmetic are verified.
