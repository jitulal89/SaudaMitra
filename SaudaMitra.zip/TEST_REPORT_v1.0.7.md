# SaudaMitra v1.0.7 — Accounts, Billing & Purchase Repair Candidate

## Source changes included
- Added Customer & Vendor Payments page with bill-level Receive/Pay actions and party-level payment entry.
- Party-level receipts/payments allocate FIFO against the oldest outstanding invoices for that customer/vendor; a selected bill can be paid directly. Prevents overpayment of party outstanding and checks selected bill belongs to the selected party.
- Added Broker Management with percentage commission, SELF at 0%, search, earned/paid/outstanding view and invoice commission report. New sales calculate commission from the configured rate; commission is not included in customer invoice totals or shown as a charge on the printed bill.
- Added broker name suggestions in billing and auto-creates an unknown typed broker at 0% until configured.
- Added State, State code, FSSAI and PIN code fields to customer/vendor setup.
- Added demo broker at 1% and three unpaid demo customer invoices (₹2,000, ₹3,000, ₹5,000) for testing ₹4,000 FIFO allocation.
- Improved OCR line parser for multi-line OCR output and known HSN/product rows; vendor name and invoice reference matching improved.
- Added mobile modal and edit-item layout CSS to prevent horizontal overflow.
- Added invoice preview options for PDF/print, WhatsApp text sharing, thermal text sharing, and paper-size selection (A4, 80mm, 58mm).
- Bumped Android app version to 1.0.7 / versionCode 5.

## Checks completed
- `node --check app/src/main/assets/www/app.js`: PASS.
- `tests/validate_source.py`: PASS.
- `app/src/main/assets/www/tests/validate_package.py`: PASS.
- `app/src/main/assets/www/tests/validate_purchase.py`: PASS, including sample parser rows for Naira and Santosh sample line layouts.
- ZIP archive integrity: checked after packaging.

## Not yet verified
- Android Gradle APK build was not run in this environment; the GitHub Actions workflow is included for building.
- Browser end-to-end smoke test could not run because Chromium navigation was blocked by the execution environment.
- No physical Android device test has been completed. In particular, native print dialog behavior, WhatsApp intent behavior, PDF OCR accuracy on the attached demo PDF, and payment flows require device-level acceptance testing before production use.
- The included demo customer invoices have no stock item lines; they exist only to test the payment allocation example and must not be treated as accounting records.

## Acceptance test
1. Load demo data on a fresh/empty test installation.
2. Open Customer & Vendor Payments → Customer receivables → select Demo Payment Customer.
3. Record ₹4,000. Expected allocations: PAY-DEMO-001 = ₹2,000 settled; PAY-DEMO-002 = ₹2,000 applied, ₹1,000 outstanding; PAY-DEMO-003 remains ₹5,000 outstanding.
4. Set Demo Broker commission to 1%; create a ₹100,000 eligible bill with Demo Broker. Expected commission ledger = ₹1,000, invoice total remains ₹100,000, and SELF commission remains ₹0.
5. Test PDF OCR using `SaudaMitra_Demo_Purchase_Bill_Fictional_Vendor_OCR_Test.pdf`; manually verify every extracted field before saving.
6. Test edit bill on a narrow Android screen, then confirm item rows and modal do not overflow horizontally and stock reversal/reposting is correct.
7. Test print dialog and share options on Android before live use.
