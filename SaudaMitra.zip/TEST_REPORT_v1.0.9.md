# SaudaMitra v1.0.9 — navigation, partial payment and print repair candidate

## Source fixes in this package
- Restored `payments` and `brokers` to the *active* `renderPage()` route map. The source had two function declarations; the later declaration overrode the earlier route map and omitted both modules, which explains why those pages did not open.
- Added an Amount Received input to the sales bill form. `saveBill()` already reads `billPaidAmount`, but the active form did not render it, so a Partial payment could not be entered.
- Changed the print action not to close the invoice modal before invoking `window.print()`. Closing first removed the invoice content from the print context.
- Added print CSS to hide navigation and modal controls while retaining the invoice body, and allow the selected paper width to apply.
- Updated draft invoice preview calculations to use each item's tax rate and include the charges already entered on the draft.
- Version metadata updated to 1.0.9 / versionCode 7.

## Automated checks performed
- `node --check app/src/main/assets/www/app.js`: PASS
- `tests/validate_source.py`: PASS
- `app/src/main/assets/www/tests/validate_package.py`: PASS
- `app/src/main/assets/www/tests/validate_purchase.py`: PASS for the repository's representative OCR line samples
- ZIP integrity: PASS
- Source assertions: active route map includes payments and brokers; active bill form contains billPaidAmount; print action no longer closes modal first; per-line tax preview and charge summary present.

## Not verified / still requires actual APK + phone testing
- Android Gradle build was not run in this environment.
- OCR on the user's exact PDF has not been proven. The screenshot shows OCR only returned 258 characters and did not identify a product row. This package still uses ML Kit OCR on a rendered PDF page; a clean JavaScript test of sample OCR text is not proof that the PDF image will be recognized on-device.
- Actual printer dialog, PDF save, Android share sheet/WhatsApp, thermal printer, broker search interaction, FIFO party-payment allocation, product search, and shop-wise stock posting need device/browser end-to-end tests.
- Do not use this repair candidate for live accounting until those checks pass.

## Manual acceptance checklist
1. Build/install APK; open Broker Management and Customer & Vendor Payments from navigation.
2. Create a bill with Partial status, enter a partial amount, save, and confirm paid/balance amounts.
3. Open a saved invoice, choose A4/80mm/58mm, print/save PDF, and verify the invoice appears in the print output.
4. Upload the exact fictional vendor OCR PDF and inspect the OCR text. Confirm all fields manually if OCR misses the product row.
5. Verify the product tax rate is per line and stock is shown for selected shop and all shops.
